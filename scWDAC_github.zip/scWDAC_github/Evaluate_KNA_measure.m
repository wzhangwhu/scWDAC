%% 
% MATLAB code for computing k-NN accuracy
clc
clear
close all
currentFolder = pwd;
addpath(genpath(currentFolder))

%  addpath('E:\scRNA_seq_sc_ATAC_seq')
addpath('F:\multi_view_dataset\scRNA_seq_sc_ATAC_seq')
addpath('F:\multi_view_dataset')
addpath('E:\scRNA_seq_sc_ATAC_seq')

% dataset={'data1_sim','data2_sim','Inhouse','SNARE','Sai','scRNA_ATAC_seq','BRCA','PBMC'};
dataset={'data1_sim','data2_sim','Sai','BRCA','SNARE','Inhouse','scRNA_ATAC_seq','new_10X10kPBMC'};

% ii=3;
for ii = 1:length(dataset)
     load(dataset{ii})

    Zn=importdata(strcat('result_representation_',dataset{ii},'.mat'));

    % k = 10; % number of nearest neighbors
    % kNN_accuracy = compute_kNN_accuracy(X, true_label, pred_labels, k);
    % disp(['k-NN accuracy: ', num2str(kNN_accuracy)]);


    % ----- 新增局部结构评估KNA ----------
    [U,Sv,~]=svds(Zn,50); M=U*sqrt(Sv);
    knnAcc = evalLocalStruct(M, true_label, 30);
    result_KNA(ii,:)=[knnAcc, lcmc];
    fprintf('k-NN Acc = %.4f, LCMC = %.4f\n',knnAcc, lcmc);
end
save scWDAC_result_KNA_k_30.mat result_KNA


function [knnAcc] = evalLocalStruct(Z, label, k)
%EVALLOCALSTRUCT 计算 k-NN Acc 与 LCMC
%   Z     : n×d 嵌入矩阵（如 scWDAC 的 M）
%   label : n×1 真实标签
%   k     : 邻居数，默认 30
%
%   knnAcc: k-NN Accuracy
%   lcmc  : Local Continuity Meta-Criterion
%
%  Example:
%       [~,S,V]=svds(W,50); M=U*sqrt(S);
%       [ka,lc]=evalLocalStruct(M,label,30);

if nargin<3, k=30; end
n = size(Z,1);
assert(numel(label)==n, 'Size mismatch');

%% ---- 1. k-NN Acc （在嵌入空间） --------------------------
% 1-1 嵌入空间 k 近邻
Dz = squareform(pdist(Z,'euclidean'));
[~, idxZ] = sort(Dz,2);          % 每行升序
idxZ = idxZ(:,2:k+1);           % 去掉自身

% 1-2 统计同标签比例
match = zeros(n,1);
for i = 1:n
    match(i) = mean(label(idxZ(i,:)) == label(i));
end
knnAcc = mean(match);


end